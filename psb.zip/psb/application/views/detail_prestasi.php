<div class="cbp-l-member-img">
	<img src="<?=base_url().$foto?>" alt="<?=$judul_foto?>" class="img-responsive" width="400px">
</div>
<div class="cbp-l-member-info">
	<div class="cbp-l-member-name"><?=$judul_foto?></div>
	<div class="cbp-l-member-desc"><?=$keterangan?></div>
</div>
