<div class="cbp-l-member-img">
	<img src="<?=base_url().$foto_pengajar?>" alt="<?=$nama_pengajar?>">
</div>
<div class="cbp-l-member-info">
	<div class="cbp-l-member-name"><?=$nama_pengajar?></div>
	<div class="cbp-l-member-position"><?=$profesi?></div>
	<div class="cbp-l-member-desc"><?=$profil?></div>
</div>
